## How to compile and test the pass

#### Structure of printf_pass_dir:

```
printf_pass_dir/
├── CMakeLists.txt
├── test.c
├── printf_pass/
│   ├── CMakeLists.txt
│   └── printf_pass.cpp
```

#### Build

###### Inside printf_pass_dir

```bash
cd ./llvm-project/printf_pass_dir
mkdir build && cd build
cmake ..
make
cd ..
clang -emit-llvm -c test.c -o test.bc
opt -load-pass-plugin ./build/printf_pass/PrintfPass.so -passes="printf-pass" test.bc -o output.bc
```

#### Run

```bash
lli output.bc
```

###### or

```bash
clang output.bc -o test; ./test
```

