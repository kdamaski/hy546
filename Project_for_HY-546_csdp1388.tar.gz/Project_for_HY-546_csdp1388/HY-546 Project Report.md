### HY-546 Project Walkthrough

##### Student: Damaskinakis Kostas - csdp1388

##### Installation process:

```bash
git clone https://github.com/llvm/llvm-project.git
mkdir build && cd build
cmake -G "Unix Makefiles" \
          -DLLVM_ENABLE_PROJECTS="clang;lld" \
          -DBUILD_SHARED_LIBS=ON \
          -DCMAKE_BUILD_TYPE=Release \
          ../llvm
make
```

This will install llvm project with clang and lld under ... ./llvm-project/build/bin/
So in order to use the binaries one would have to add this path to the PATH env variable.

###### moving on

Reading the page https://www.cs.cornell.edu/~asampson/blog/llvm.html on how to make a toy llvm pass, searching the net and trying to figure out how things work i got a basic idea and moved on to implement the PASS.
PASS code:

```c++
#include "llvm/IR/Function.h"
#include "llvm/IR/GlobalVariable.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/PassManager.h"
#include "llvm/IR/Type.h"
#include "llvm/Pass.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Support/raw_ostream.h"
#include <cstdio>

using namespace llvm;

namespace {
// Main pass logic for module
struct PrintfPass : public PassInfoMixin<PrintfPass> {
  PreservedAnalyses run(Module &M, ModuleAnalysisManager &AM) {

    FILE *logFile;
    for (Function &F : M) {
      if (F.getName() == "main") {
        IRBuilder<> Builder(F.getContext());
        logFile = fopen("log.txt", "w");
        break; // We only need to insert once at the start of main
      }
    }

    // Extract the message to be logged (assumes first argument is format
    // string)
    for (Function &F : M) {
      for (BasicBlock &BB : F) {
        for (Instruction &I : BB) {
          if (auto *callInst = dyn_cast<CallBase>(&I)) {
            Function *calledFunction = callInst->getCalledFunction();
            if (calledFunction && calledFunction->getName() == "printf") {
              // Get the first argument of the printf call
              Value *messageToPrint = callInst->getArgOperand(0);
              if (auto *globalVar = dyn_cast<GlobalVariable>(messageToPrint)) {
                if (auto *constData = dyn_cast<ConstantDataArray>(
                        globalVar->getInitializer())) {
                  if (constData->isCString()) {
                    // Extract the C string from the constant data
                    StringRef formatString = constData->getAsCString();
                    fprintf(logFile, "%s\n", formatString.data());
                  }
                }
              }
            }
          }
        }
      }
    }

    for (Function &F : M) {
      if (F.getName() == "main") {
        IRBuilder<> Builder(F.getContext());
        fclose(logFile);
        break;
      }
    }
    return PreservedAnalyses::all();
  }
};
} // namespace

// Register the pass with the new pass manager
extern "C" LLVM_ATTRIBUTE_WEAK PassPluginLibraryInfo llvmGetPassPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "PrintfPass", "v0.1", [](PassBuilder &PB) {
            PB.registerPipelineParsingCallback(
                [](StringRef Name, ModulePassManager &MPM,
                   ArrayRef<PassBuilder::PipelineElement>) {
                  if (Name == "printf-pass") {
                    MPM.addPass(PrintfPass());
                    return true;
                  }
                  errs() << "Unrecognized pass\n";
                  return false;
                });
          }};
}
```

###### Structure of printf_pass_dir:

```
printf_pass_dir/
├── CMakeLists.txt
├── test.c
├── printf_pass/
│   ├── CMakeLists.txt
│   └── printf_pass.cpp
```



##### How to build and run

After the executables are prepended in your PATH env enter the directory named "printf_pass_dir".
So the steps are the following:

```bash
cd ./llvm-project/printf_pass_dir
mkdir build && cd build
cmake ..
make
cd ..
clang -emit-llvm -c test.c -o test.bc
opt -load-pass-plugin ./build/printf_pass/PrintfPass.so -passes="printf-pass" test.bc -o output.bc
lli output.bc # or clang output.bc -o test; ./test
```

